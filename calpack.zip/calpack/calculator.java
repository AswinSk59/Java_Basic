package calpack;
public class calculator{
	public void add(int a,int b){
		System.out.println("sum="+(a+b));
	}
	public void sub(int a,int b){
		System.out.println("Difference="+(a-b));
	}
} 
